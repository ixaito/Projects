#Name: Yogenthirran
#RegNum:01DDT21F1071
import mysql.connector
mydb = mysql.connector.connect (
    host = "localhost",
    port = "3307",
    user = "root",
    password = "1234",
    database = "MyDatabase2"
    )

mycursor = mydb.cursor()
#mycursor.execute("CREATE DATABASE MyDatabase2")
#mycursor.execute("CREATE TABLE ticketRecord(name VARCHAR(225),destination VARCHAR(225),quantityAdult INTEGER(3),quantityChilder INTEGER(3),totalPayment DECIMAL)")

def insert():
    mycursor = mydb.cursor()
    varDestination = destination.get()
    varQuantityA = quantityAdult.get()
    valQuantityB = quantityChilder.get()
    tPayment = totalPayment

    if varDestination == "Kuantan":
        tPayment = ((varQuantityA*20)+(valQuantityB*17.5))
        totalPayment.set(tPayment)
    elif varDestination == "Seremban":
        tPayment = ((varQuantityA*35) + (valQuantityB*20.5))
        totalPayment.set(tPayment)
    elif varDestination == "Mersing":
        tPayment = ((varQuantityA*45.8) + (valQuantityB*30))
        totalPayment.set(tPayment)
    else:
        tPayment = 0.0
        totalPayment.set(tPayment)
    
    mycursor = mydb.cursor()
    sql = "INSERT INTO ticketRecord(name,destination,quantityAdult,quantityChilder,totalPayment) VALUES (%s, %s, %s, %s, %s)"
    val = (name.get(),destination.get(),quantityAdult.get(),quantityChilder.get(),tPayment)
    mycursor.execute(sql,val)
    
    mydb.commit()
  
    
    mycursor.execute("SELECT * FROM ticketRecord")
    
    myresult = mycursor.fetchall()
    
    for x in myresult:
        print(x)
        

   
        
from tkinter import *
master = Tk()
name = StringVar()
destination = StringVar()
quantityAdult = IntVar()
quantityChilder = IntVar()
totalPayment = IntVar()

Label(master, text='Name: ').grid(row=0, column=0)
Label(master, text= 'Destination: ').grid(row=1,column=0)
Label(master, text='Quantity of Adult: ').grid(row=2, column=0)
Label(master, text='Quantity of Children: ').grid(row=3, column=0)
Label(master, text='', textvariable=totalPayment).grid(row=5, columnspan=2)

Entry(master, textvariable=name).grid(row=0, column=3)
Entry(master, textvariable=destination).grid(row=1, column=3)
Entry(master, textvariable=quantityAdult).grid(row=2, column=3)
Entry(master, textvariable=quantityChilder).grid(row=3, column=3)

Button(master,text='Submit', command = insert).grid(row=4, columnspan=2)

mainloop()

